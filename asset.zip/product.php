<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                    },
                },
                screens: {
                    ss: "320px",
                    // => @media (min-width: 640px) { ... }

                    sm: "375px",
                    sl: "425px",

                    md: "768px",
                    // => @media (min-width: 768px) { ... }

                    lg: "1024px",
                    // => @media (min-width: 1024px) { ... }

                    xl: "1280px",
                    // => @media (min-width: 1280px) { ... }

                    desktop: "1440px",
                    // => @media (min-width: 1536px) { ... }
                },
            },
            container: {
                padding: {
                    DEFAULT: "1rem",
                    sm: "2rem",
                    lg: "4rem",
                    xl: "5rem",
                    "2xl": "6rem",
                },
            },
        }
    </script>
</head>

<body>
    <!-- component -->
    <div>
        <div class="min-h-screen flex flex-col flex-auto flex-shrink-0 antialiased bg-gray-50  text-black ">
            <?php
            include('./include/sidebar.php');

            ?>
            <div class="h-full ml-14 mt-14 mb-10 md:ml-64 md:px-20 xl:px-40">
                <div class="h-2 bg-pink-400 rounded-t-md"></div>
                <form class="bg-white p-10 rounded-lg shadow-xl min-w-full">
                    <h1 class="text-center text-2xl mb-6 text-gray-600 font-bold font-sans"></h1>

                    <div class="grid xl:grid-cols-3 grid-cols-1 gap-4">
                        <div>
                            <label class="text-gray-800 font-semibold block my-3 text-md" for="username">Vendor
                                List</label>
                            <input class="w-full bg-gray-100 px-4 py-2 rounded-lg focus:outline-none" type="text" name="username" id="username" placeholder="Vendor List" />
                        </div>

                        <div>
                            <label class="text-gray-800 font-semibold block my-3 text-md" for="email">Product
                                Code</label>
                            <input class="w-full bg-gray-100 px-4 py-2 rounded-lg focus:outline-none" type="text" name="email" id="email" placeholder="Product Code" />
                        </div>
                        <div class="">
                            <label class="text-gray-800 font-semibold block my-3 text-md" for="email">
                                Code</label>
                            <input class="w-full bg-gray-100 px-4 py-2 rounded-lg focus:outline-none" type="text" name="email" id="email" placeholder="Code" />
                        </div>
                    </div>

                    <div class="grid xl:grid-cols-3 grid-cols-1 gap-4">
                        <div>
                            <label class="text-gray-800 font-semibold block my-3 text-md" for="username">Device
                                Type</label>
                            <input class="w-full bg-gray-100 px-4 py-2 rounded-lg focus:outline-none" type="text" name="username" id="username" placeholder="Device" />
                        </div>

                        <div>
                            <label class="text-gray-800 font-semibold block my-3 text-md" for="email">Description</label>
                            <input class="w-full bg-gray-100 px-4 py-2 rounded-lg focus:outline-none" type="text" name="text" id="email" placeholder="Description" />
                        </div>
                        <div class="">
                            <label class="text-gray-800 font-semibold block my-3 text-md" for="email">Quantity</label>
                            <input class="w-full bg-gray-100 px-4 py-2 rounded-lg focus:outline-none" type="text" name="text" id="email" placeholder="Qty" />
                        </div>
                    </div>
                    <div class="grid xl:grid-cols-3 grid-cols-1 gap-4">
                        <div>
                            <label class="text-gray-800 font-semibold block my-3 text-md" for="username">HSN/SAC
                                List</label>
                            <input class="w-full bg-gray-100 px-4 py-2 rounded-lg focus:outline-none" type="text" name="username" id="username" placeholder="HSN/SAC" />
                        </div>

                        <div>
                            <label class="text-gray-800 font-semibold block my-3 text-md" for="email">Invoice
                                Number</label>
                            <input class="w-full bg-gray-100 px-4 py-2 rounded-lg focus:outline-none" type="text" name="email" id="email" placeholder="Invoice number" />
                        </div>
                        <div class="">
                            <label class="text-gray-800 font-semibold block my-3 text-md" for="email">Invoice
                                Date</label>
                            <input class="w-full bg-gray-100 px-4 py-2 rounded-lg focus:outline-none" type="text" name="email" id="email" placeholder="Invoice Date" />
                        </div>
                    </div>
                    <div class="grid xl:grid-cols-3 grid-cols-1 gap-4">
                        <div>
                            <label class="text-gray-800 font-semibold block my-3 text-md" for="username">Amount
                                List</label>
                            <input class="w-full bg-gray-100 px-4 py-2 rounded-lg focus:outline-none" type="text" name="username" id="username" placeholder="Amount" />
                        </div>

                        <div>
                            <label class="text-gray-800 font-semibold block my-3 text-md" for="email">CGST 9%</label>
                            <input class="w-full bg-gray-100 px-4 py-2 rounded-lg focus:outline-none" type="text" name="email" id="email" placeholder="CGST" />
                        </div>
                        <div class="">
                            <label class="text-gray-800 font-semibold block my-3 text-md" for="email">SGST 9%</label>
                            <input class="w-full bg-gray-100 px-4 py-2 rounded-lg focus:outline-none" type="text" name="email" id="email" placeholder="SGST" />
                        </div>
                    </div>
                    <div class="grid xl:grid-cols-3 grid-cols-1 gap-4">
                        <div>
                            <label class="text-gray-800 font-semibold block my-3 text-md" for="username">Warranty</label>
                            <input class="w-full bg-gray-100 px-4 py-2 rounded-lg focus:outline-none" type="text" name="username" id="username" placeholder="Warranty" />
                        </div>

                        <div>
                            <label class="text-gray-800 font-semibold block my-3 text-md" for="email">Expired
                                Date</label>
                            <input class="w-full bg-gray-100 px-4 py-2 rounded-lg focus:outline-none" type="text" name="email" id="email" placeholder="Expired Date" />
                        </div>
                        <div class="">
                            <label class="text-gray-800 font-semibold block my-3 text-md" for="email">Emp Code</label>
                            <input class="w-full bg-gray-100 px-4 py-2 rounded-lg focus:outline-none" type="text" name="email" id="email" placeholder="Emp code" />
                        </div>
                    </div>
                    <div class="grid xl:grid-cols-3 grid-cols-1 gap-4">
                        <div>
                            <label class="text-gray-800 font-semibold block my-3 text-md" for="username">Facility</label>
                            <input class="w-full bg-gray-100 px-4 py-2 rounded-lg focus:outline-none" type="text" name="username" id="username" placeholder="Facility" />
                        </div>

                        <div>
                            <label class="text-gray-800 font-semibold block my-3 text-md" for="email">Deparment</label>
                            <input class="w-full bg-gray-100 px-4 py-2 rounded-lg focus:outline-none" type="text" name="email" id="email" placeholder="Department" />
                        </div>
                        <div class="">
                            <label class="text-gray-800 font-semibold block my-3 text-md" for="email">Department
                                Code</label>
                            <input class="w-full bg-gray-100 px-4 py-2 rounded-lg focus:outline-none" type="text" name="email" id="email" placeholder="Departmentcode" />
                        </div>
                    </div>

                    <div class="grid gap-4 place-content-center">
                        <button type="submit" class=" mt-6 mb-3 bg-pink-500 hover:bg-sky-800 rounded-lg px-4 py-2 text-lg text-white tracking-wide font-semibold font-sans">Submit</button>
                    </div>



                </form>
            </div>
        </div>

</body>

</html>