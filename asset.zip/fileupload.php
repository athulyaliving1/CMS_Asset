<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>


<body>

    <!-- component -->
    <div>
        <div class="min-h-screen flex flex-col flex-auto flex-shrink-0 antialiased bg-gray-50  text-black ">
            <?php
       include('./include/sidebar.php');
           
           ?>
            <div
                class="relative flex w-full h-full   text-gray-800 antialiased flex-col justify-center overflow-hidden bg-gray-50 py-6 sm:py-12">
                <div class="relative py-3 sm:w-96 mx-auto text-center">
                    <span class="text-2xl font-semibold ">File Upload</span>
                    <div class="mt-4 bg-white shadow-xl rounded-lg text-left">
                        <div class="h-2 bg-pink-400 rounded-t-md"></div>
                        <div class="px-8 py-6 ">
                            <label class="block font-semibold">Upload Excel File</label>
                            <input type="file" placeholder="Enter Branch Name"
                                class="border w-full py-3 mt-2 hover:outline-none focus:outline-none focus:ring-sky-900 focus:ring-1 rounded-md">
                            <div class="flex justify-end items-baseline">
                                <button type="submit"
                                    class="mt-4 bg-pink-500 text-white py-2 px-6 rounded-md hover:bg-pink-600 ">Sumbit</button>

                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
</body>

</html>